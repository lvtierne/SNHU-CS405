#include <iostream>
#include <stdexcept> // Include for standard exceptions

// Custom exception class derived from std::exception
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom exception occurred";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throwing a standard exception
    throw std::runtime_error("Standard exception occurred");

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

void do_custom_application_logic()
{
    // Wrapping the call to do_even_more_custom_application_logic() with an exception handler
    std::cout << "Running Custom Application Logic." << std::endl;
    try
    {
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    // Throwing a custom exception and catching it explicitly in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Handling divide by zero errors using a standard C++ defined exception
    if (den == 0)
    {
        throw std::invalid_argument("Division by zero error");
    }
    return (num / den);
}

void do_division() noexcept
{
    // Creating an exception handler to capture ONLY the exception thrown by divide
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        // Creating exception handlers that catch (in this order):
        // - Custom exception
        // - std::exception
        // - Uncaught exception that wraps the whole main function
        //   and displays a message to the console
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Standard Exception caught: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Unhandled Exception caught" << std::endl;
    }

    return 0;
}
